library(N2R)

testthat::test_check("N2R")
